getInterpolationMethodNames = function() {
	return(c("interpolate", "interpolateBlock", "test"))
}
